import createBrowserHistory from 'history/createBrowserHistory'

export default createBrowserHistory()
