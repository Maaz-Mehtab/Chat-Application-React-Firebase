import React, { Component } from 'react';
import {Editui} from '../componentui/edit';
import {send, chang} from '../store/action/action'

import { connect } from 'react-redux'
class Edit extends Component{
    constructor(props){
        super(props);
        this.state={
            
        }
        

    }



    render(){
        
        return(
            <div>
                
                <Editui/>
                    
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    // console.log("@@@",state.root.total)
    return {
        // currentUser: state.root.currentUser,
        // users: state.root.users,
        // send: state.root.send,
        // messagesend: state.root.messagesend,
        // messagereceived: state.root.messagereceived,
        // change: state.root.change,
        // total: state.root.total,
        // show:state.root.show,
        // all_message:state.root.all_message
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        // issend: (data) => {
        //     dispatch(send(data))
        // },
        // ischang: (data) => {
        //     dispatch(chang(data))
        // },
        // istotal: (tota) => {
        //     dispatch(total(tota))
        // },
        // ishow :(data1,data2,data3) =>{
        //     dispatch(show(data1,data2,data3))
        // },
        // isfuc :(data)=>{
        //     dispatch(fun(data))
        // },
        // isdisplay :() =>{
        //     dispatch(display())
        // }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Edit);