import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import '../index.css';


export class Editui extends Component {
    render() {
        const prop = this.props
        // console.log("props",prop.users)

        return (

            <div>
                



                <div className="container">
        <h2>POPup Example</h2>

        <button type="button" className="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Window</button>


        <div className="modal fade" id="myModal" role="dialog">
            <div className="modal-dialog">


                <div className="modal-content">
                    <div className="modal-header">
                        <h4 className="modal-title">PopUp Header</h4>
                        <button type="button" className="close" data-dismiss="modal" className="float-right">&times;</button>
                    </div>
                    <div className="modal-body">
                        <div className="container">

                            <form className="form-signin" id="stop">
                                <h2 className="form-signin-heading">Please sign in</h2>
                                <label for="inputEmail" className="sr-only">Email address</label>
                                <input type="email" id="lemail" className="form-control" placeholder="Email address" required autofocus/>

                                <label for="inputPassword" className="sr-only">Password</label>
                                <input type="password" id="lpass" className="form-control mt-2" placeholder="Password" required/>

                                <button className="btn btn-lg btn-success btn-block " type="submit">Sign in</button>
                            </form>


                        </div>
                        
                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>

            </div>
        </div>

    </div>





            </div>
        )
    }
}